<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tentang BK - SMKN 7 Samarinda</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>body { font-family: 'Plus Jakarta Sans', sans-serif; }</style>
</head>
<body class="bg-light">
    <div class="container py-5">
        <a href="/" class="btn btn-outline-dark mb-5 rounded-pill">&larr; Kembali ke Portal</a>
        
        <div class="row justify-content-center">
            <div class="col-lg-10 text-center mb-5">
                <span class="text-primary fw-bold text-uppercase" style="letter-spacing: 2px; font-size: 0.85rem;">Kenali Layanan Kami</span>
                <h2 class="fw-bolder mb-4 mt-2" style="font-size: 2.5rem; color: #0B2447;">Ruang Aman untuk Berkembang</h2>
                
                <p class="text-secondary mx-auto" style="line-height: 1.8; font-size: 1.15rem;">
                    Bimbingan dan Konseling (BK) adalah ruang aman, teman bercerita, tempat bertanya, dan penuntun langkah bagi setiap siswa di <strong>SMKN 7 Samarinda</strong>.
                </p>
                <p class="text-secondary mx-auto mt-3" style="line-height: 1.8; font-size: 1.1rem;">
                    Masa sekolah tidak selalu mudah. Terkadang kamu dihadapkan pada tuntutan belajar, dinamika pertemanan, kebingungan jalur karier, hingga masalah pribadi yang sulit diceritakan. Di sinilah BK hadir untuk mendengarkan tanpa menghakimi. Kami memastikan <strong>kamu tidak pernah menghadapi semua itu sendirian</strong>.
                </p>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH D:\XAMPP\Konseling\Konseling\resources\views/tentang.blade.php ENDPATH**/ ?>