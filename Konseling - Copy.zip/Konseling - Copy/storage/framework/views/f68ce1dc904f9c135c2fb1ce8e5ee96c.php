<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($peran); ?> - E-Konseling SMKN 7</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: #f4f7fb; }
        .bg-navy { background-color: #0B2447; }
        .text-gold { color: #FFD700; }
        .text-navy { color: #0B2447; }
        .btn-gold { background: #FFD700; color: #0B2447; font-weight: 700; }
        .btn-gold:hover { background: #e6c200; color: #0B2447; }
    </style>
</head>
<body>
    <nav class="navbar bg-navy py-3">
        <div class="container">
            <span class="navbar-brand text-white fw-bold"><span class="text-gold">E-</span>Konseling SMKN 7</span>
            <form method="POST" action="<?php echo e(route('logout')); ?>" class="m-0">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-gold rounded-pill px-4"><i class="bi bi-box-arrow-right me-1"></i> Keluar</button>
            </form>
        </div>
    </nav>

    <main class="container py-5">
        <div class="bg-white rounded-4 shadow-sm p-4 p-md-5">
            <span class="badge text-bg-primary rounded-pill mb-3"><?php echo e($peran); ?></span>
            <h1 class="fw-bolder text-navy">Selamat datang, <?php echo e($nama); ?>!</h1>
            <p class="text-secondary mb-4"><?php echo e($info); ?></p>
            <div class="alert alert-info mb-0">
                <i class="bi bi-info-circle me-1"></i>
                Login berhasil. Halaman ini sementara; fitur back end (tambah, ubah, hapus, cari data) dibuat di tahap berikutnya.
            </div>
        </div>
    </main>
</body>
</html>
<?php /**PATH D:\XAMPP\htdocs\Konseling\Konseling\resources\views/dashboard.blade.php ENDPATH**/ ?>