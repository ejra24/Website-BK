<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Layanan BK - SMKN 7 Samarinda</title>
    
    <!-- Memanggil Google Fonts (Plus Jakarta Sans) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Memanggil Bootstrap CSS & Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    
    <style>
        body { 
            font-family: 'Plus Jakarta Sans', sans-serif; 
            background-color: #f8f9fa; /* bg-light bawaan bootstrap */
        }
        .text-navy { color: #0B2447; }
        .text-blue-accent { color: #0d6efd; }
        .text-gold { color: #f78b00; }

        /* Kustomisasi Kartu Layanan */
        .service-card {
            transition: all 0.3s ease;
            cursor: pointer;
            border: 1px solid transparent;
        }
        .service-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.1) !important;
            border-color: #0d6efd;
        }
        .icon-box {
            width: 80px; 
            height: 80px;
            background-color: #e0f0ff;
            transition: all 0.3s ease;
        }
        .service-card:hover .icon-box {
            background-color: #0d6efd;
        }
        .service-card:hover .icon-box i {
            color: #ffffff !important;
        }
        
        .btn-outline-custom {
            border: 2px solid #0B2447;
            color: #0B2447;
            font-weight: 700;
        }
        .btn-outline-custom:hover {
            background-color: #0B2447;
            color: white;
        }
    </style>
</head>
<body>
    <div class="container py-5">
        
        <!-- Tombol Kembali -->
        <a href="/" class="btn btn-outline-dark mb-4 rounded-pill">
            <i class="bi bi-arrow-left me-2"></i>Kembali ke Portal
        </a>
        
        <!-- Header Halaman -->
        <div class="text-center mb-5 mt-3">
            <span class="text-blue-accent fw-bold text-uppercase" style="letter-spacing: 2px; font-size: 0.85rem;">Fasilitas Utama Kami</span>
            <h2 class="fw-bolder mt-2 text-navy" style="font-size: 2.5rem;">Layanan E-Konseling</h2>
            <p class="text-secondary mx-auto" style="max-width: 650px; font-size: 1.1rem; line-height: 1.6;">
                Pilih layanan yang kamu butuhkan. Semua pengajuan jadwal dan sesi konsultasi dijamin kerahasiaannya oleh sistem. Silakan masuk (login) terlebih dahulu untuk membuat janji temu.
            </p>
        </div>

        <!-- Baris Kartu Layanan -->
        <div class="row g-4 justify-content-center">
            
            <!-- Layanan 1: E-Konseling Pribadi -->
            <div class="col-md-6 col-lg-4">
                <div class="card h-100 bg-white border-0 shadow-sm rounded-4 p-4 text-center service-card">
                    <div class="icon-box rounded-circle d-inline-flex align-items-center justify-content-center mx-auto mb-4">
                        <i class="bi bi-chat-dots fs-1 text-primary"></i>
                    </div>
                    <h4 class="fw-bold text-navy">E-Konseling Pribadi</h4>
                    <p class="text-secondary mb-4 mt-2">Jadwalkan sesi curhat atau konsultasi masalah pribadi dengan guru BK secara online tanpa merasa canggung atau takut dihakimi.</p>
                    <a href="/login" class="btn btn-outline-custom rounded-pill mt-auto px-4 py-2">Buat Janji</a>
                </div>
            </div>

            <!-- Layanan 2: Bimbingan Karir -->
            <div class="col-md-6 col-lg-4">
                <div class="card h-100 bg-white border-0 shadow-sm rounded-4 p-4 text-center service-card">
                    <div class="icon-box rounded-circle d-inline-flex align-items-center justify-content-center mx-auto mb-4">
                        <i class="bi bi-compass fs-1 text-gold"></i>
                    </div>
                    <h4 class="fw-bold text-navy">Bimbingan Karir & PKL</h4>
                    <p class="text-secondary mb-4 mt-2">Eksplorasi minat bakatmu, siapkan diri untuk masuk dunia kerja, dan konsultasikan pemilihan tempat Praktik Kerja Lapangan (PKL) yang tepat.</p>
                    <a href="/login" class="btn btn-outline-custom rounded-pill mt-auto px-4 py-2">Mulai Tes</a>
                </div>
            </div>

            <!-- Layanan 3: Konsultasi Akademik -->
            <div class="col-md-6 col-lg-4">
                <div class="card h-100 bg-white border-0 shadow-sm rounded-4 p-4 text-center service-card">
                    <div class="icon-box rounded-circle d-inline-flex align-items-center justify-content-center mx-auto mb-4">
                        <i class="bi bi-journal-bookmark fs-1 text-success"></i>
                    </div>
                    <h4 class="fw-bold text-navy">Konsultasi Akademik</h4>
                    <p class="text-secondary mb-4 mt-2">Dapatkan bantuan untuk menyelesaikan masalah belajar, penurunan nilai, atau kesulitan beradaptasi dengan mata pelajaran kejuruan.</p>
                    <a href="/login" class="btn btn-outline-custom rounded-pill mt-auto px-4 py-2">Konsultasi</a>
                </div>
            </div>

        </div>
    </div>
</body>
</html><?php /**PATH D:\XAMPP\Konseling\Konseling\resources\views/layanan.blade.php ENDPATH**/ ?>